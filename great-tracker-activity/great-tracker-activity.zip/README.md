# ⏱️ GreatTrackerActivity - Smart Focus & Micro-Activity Tracker

Ekstensi browser Chrome / Chromium (Manifest V3) untuk melacak waktu aktivitas secara **mikro & presisi** pada situs produktivitas populer (**ChatGPT**, **YouTube**, dan **GitHub**) dengan fitur **Smart Auto-Pause 15 Detik** saat kursor diam atau pengguna beralih ke aplikasi luar di OS.

---

## 🌟 Fitur Utama

### 1. Deteksi Aktivitas Mikro (Granular Actions)
Bukan sekadar mencatat domain ("1 jam di YouTube"), melainkan membedah sub-aktivitas secara detail:

- **ChatGPT (`chatgpt.com`):**
  - 📖 **Membaca respons AI:** Viewport/scroll sedang membaca respons percakapan.
  - ⌨️ **Mengetik prompt:** Sedang aktif mengetik di textarea / input chat.
  - ⏳ **Menunggu AI streaming:** Deteksi tombol *Stop generating* / teks sedang dibuat oleh AI.
  - 📋 **Copy code:** Klik tombol *Copy code* pada blok kode.
  - 📎 **Upload berkas:** Interaksi dengan tombol lampiran atau dialog upload berkas.

- **YouTube (`youtube.com`):**
  - 🎬 **Menonton video:** Pemutar video HTML5 sedang berjalan (`!video.paused`).
  - 🔍 **Mencari video:** Berada di halaman `/results` atau sedang mengetik di kotak pencarian.
  - 💬 **Komentar:** Sedang membaca atau mengetik di area `#comments`.
  - 📱 **Shorts:** Menonton video vertikal di `/shorts/*`.
  - 🧭 **Jelajah feed:** Berada di beranda, langganan, atau halaman channel.

- **GitHub (`github.com`):**
  - 📄 **Membaca README:** Scroll viewport sedang menampilkan section `#readme`.
  - 💻 **Coding / Review file:** Sedang membuka berkas kode (`/blob/`, `/edit/`, atau Monaco web editor).
  - 🐞 **Melihat Issue:** Menjelajahi laporan masalah di `/issues/*`.
  - 🔀 **Meninjau Pull Request:** Meninjau percakapan PR atau tab *Files changed* di `/pull/*`.
  - 📂 **Jelajah repositori:** Melihat daftar berkas dan commit.

---

### 2. Mekanisme Smart Auto-Pause
- **Kursor / Interaksi Diam (15 Detik):** Jika tidak ada gerakan mouse (`mousemove`), scroll, atau ketikan keyboard selama **15 detik**, timer pelacakan **langsung DIJEDA (PAUSE)** secara otomatis. Begitu kursor digerakkan kembali, timer **langsung RESUME**.
- **Beralih ke Aplikasi Luar (Di luar Chrome):** Saat pengguna berpindah ke VS Code, Terminal, Spotify, Discord, atau game di OS, ekstensi mendeteksi event `chrome.windows.onFocusChanged` (`WINDOW_ID_NONE`) & `window.onblur`, seketika menghentikan pencatatan waktu agar tidak ada waktu "bengong" yang terhitung.
- **Ganti Tab:** Berpindah tab langsung mem-pause tab lama dan mengaktifkan adapter tab baru jika didukung.

---

## 🚀 Cara Memasang Ekstensi di Chrome / Brave / Edge

1. Buka browser dan ketik alamat:
   ```
   chrome://extensions/
   ```
2. Aktifkan sakelar **Developer mode** (Mode pengembang) di pojok kanan atas.
3. Klik tombol **Load unpacked** (Muat yang belum dibongkar) di pojok kiri atas.
4. Pilih folder:
   ```
   /home/egi/MyKodingGweh/SCIGROUP/GreatTrackerActivity
   ```
5. Ikon **GreatTrackerActivity** akan muncul di bilah ekstensi Chrome Anda. Sematkan (*pin*) ikon agar mudah dipantau.

---

## 📁 Struktur Berkas

```
GreatTrackerActivity/
├── manifest.json              # Konfigurasi Manifest V3 & izin
├── background.js              # Master Timer, Window Focus & Storage Hub
├── core/
│   ├── idle-detector.js       # Engine deteksi kursor diam 15s & window blur
│   └── storage.js             # Skema & fungsi chrome.storage.local
├── adapters/
│   ├── chatgpt.js             # Adapter aktivitas mikro ChatGPT
│   ├── youtube.js             # Adapter aktivitas mikro YouTube
│   └── github.js              # Adapter aktivitas mikro GitHub
├── popup/
│   ├── popup.html             # Tampilan dashboard popup Dark Mode
│   ├── popup.css              # Styling modern Dark Mode
│   └── popup.js               # Logika render status & breakdown waktu
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## 🔒 Privasi & Keamanan Data
- Ekstensi ini berjalan **100% secara lokal** di browser Anda.
- Seluruh riwayat waktu disimpan di `chrome.storage.local` dan **tidak pernah dikirimkan ke server eksternal mana pun**.
- Anda dapat mereset data atau mengekspornya ke format JSON kapan saja melalui tombol di jendela Popup.
