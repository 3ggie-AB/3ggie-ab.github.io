/**
 * GreatTrackerActivity - YouTube Domain Adapter
 * Mendeteksi aktivitas mikro: Menonton video, Mencari video, Membaca/Menulis komentar, Menonton Shorts
 */

(function () {
  const PLATFORM = 'youtube';
  let currentActivity = 'browsing';
  let isCommenting = false;
  let commentTimeout = null;

  function updateActivity(newActivity) {
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      newActivity = 'idle';
    }

    if (currentActivity !== newActivity) {
      currentActivity = newActivity;
      try {
        chrome.runtime.sendMessage({
          type: 'ACTIVITY_CHANGED',
          platform: PLATFORM,
          activity: currentActivity,
        });
      } catch (_) {}
    }
  }

  function isVideoPlaying() {
    const video = document.querySelector('video');
    return video && !video.paused && !video.ended && video.readyState > 2;
  }

  function isShortsPage() {
    return window.location.pathname.startsWith('/shorts');
  }

  function isSearchPageOrActive() {
    if (window.location.pathname === '/results') return true;
    const active = document.activeElement;
    if (active && (active.id === 'search' || active.getAttribute('name') === 'search_query')) {
      return true;
    }
    return false;
  }

  function setupCommentListener() {
    document.addEventListener(
      'focusin',
      (e) => {
        const target = e.target;
        if (target && target.closest('#comments, #comment-dialog, ytd-commentbox, ytd-comments')) {
          isCommenting = true;
          clearTimeout(commentTimeout);
          evaluateActivity();
        }
      },
      { passive: true }
    );

    document.addEventListener(
      'input',
      (e) => {
        const target = e.target;
        if (target && target.closest('#comments, ytd-commentbox')) {
          isCommenting = true;
          clearTimeout(commentTimeout);
          evaluateActivity();

          commentTimeout = setTimeout(() => {
            isCommenting = false;
            evaluateActivity();
          }, 4000);
        }
      },
      { passive: true }
    );
  }

  function evaluateActivity() {
    // 1. Shorts priority
    if (isShortsPage()) {
      updateActivity('shorts');
      return;
    }

    // 2. Jika sedang menonton video aktif, jangan idle walau kursor diam (kecuali tab blur)
    if (isVideoPlaying()) {
      updateActivity('watching_video');
      return;
    }

    // 3. Jika kursor diam > 15 detik dan tidak sedang nonton video
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      updateActivity('idle');
      return;
    }

    // 4. Pencarian video
    if (isSearchPageOrActive()) {
      updateActivity('search_video');
      return;
    }

    // 5. Komentar
    if (isCommenting) {
      updateActivity('comments');
      return;
    }

    // 6. Jelajah feed/channel
    updateActivity('browsing');
  }

  // Listener idle
  if (window.GreatIdleDetector) {
    window.GreatIdleDetector.onStateChange((isIdle) => {
      if (isIdle && !isVideoPlaying() && !isShortsPage()) {
        updateActivity('idle');
      } else {
        evaluateActivity();
      }
    });
  }

  // Listener event video HTML5
  function bindVideoEvents() {
    const video = document.querySelector('video');
    if (video && !video.__greatTrackerBound) {
      video.__greatTrackerBound = true;
      video.addEventListener('play', evaluateActivity);
      video.addEventListener('pause', evaluateActivity);
      video.addEventListener('ended', evaluateActivity);
    }
  }

  setInterval(() => {
    bindVideoEvents();
    evaluateActivity();
  }, 1500);

  // Respons ke background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'QUERY_ACTIVITY') {
      evaluateActivity();
      sendResponse({
        activity: currentActivity,
        isIdle: window.GreatIdleDetector ? window.GreatIdleDetector.isIdle() : false,
      });
    }
  });

  setupCommentListener();
  evaluateActivity();

  console.log('[GreatTracker] YouTube Adapter Loaded.');
})();
