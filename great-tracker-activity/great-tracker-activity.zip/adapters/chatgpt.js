/**
 * GreatTrackerActivity - ChatGPT Domain Adapter
 * Mendeteksi aktivitas mikro: Membaca, Mengetik, Menunggu AI, Copy Code, Upload Berkas
 */

(function () {
  const PLATFORM = 'chatgpt';
  let currentActivity = 'reading'; // default
  let isTyping = false;
  let typingTimeout = null;
  let isUploading = false;
  let uploadTimeout = null;
  let isCopying = false;
  let copyTimeout = null;

  function updateActivity(newActivity) {
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      newActivity = 'idle';
    }

    if (currentActivity !== newActivity) {
      currentActivity = newActivity;
      try {
        chrome.runtime.sendMessage({
          type: 'ACTIVITY_CHANGED',
          platform: PLATFORM,
          activity: currentActivity,
        });
      } catch (_) {}
    }
  }

  // 1. Deteksi "Menunggu AI" (Streaming / Thinking Response)
  function isAiGenerating() {
    const stopBtn =
      document.querySelector('button[data-testid="stop-button"]') ||
      document.querySelector('button[aria-label*="Stop"]') ||
      document.querySelector('.result-streaming') ||
      document.querySelector('[data-testid="fruitjuice-send-button"] svg path[d*="M2 12"]');
    return !!stopBtn;
  }

  // 2. Deteksi "Mengetik Prompt"
  function setupTypingDetection() {
    document.addEventListener(
      'input',
      (e) => {
        const target = e.target;
        if (
          target &&
          (target.id === 'prompt-textarea' ||
            target.getAttribute('contenteditable') === 'true' ||
            target.tagName === 'TEXTAREA')
        ) {
          isTyping = true;
          clearTimeout(typingTimeout);
          evaluateActivity();

          typingTimeout = setTimeout(() => {
            isTyping = false;
            evaluateActivity();
          }, 3500); // Setelah 3.5 detik tidak ketik lagi, kembali ke membaca/menunggu
        }
      },
      { passive: true, capture: true }
    );
  }

  // 3. Deteksi "Copy Code" & "Upload File"
  function setupClickActions() {
    document.addEventListener(
      'click',
      (e) => {
        const btn = e.target.closest('button, [role="button"], input[type="file"]');
        if (!btn) return;

        const text = (btn.innerText || '').toLowerCase();
        const aria = (btn.getAttribute('aria-label') || '').toLowerCase();
        const testId = (btn.getAttribute('data-testid') || '').toLowerCase();

        // Copy code detection
        if (
          text.includes('copy') ||
          aria.includes('copy') ||
          testId.includes('copy') ||
          btn.closest('pre')
        ) {
          isCopying = true;
          clearTimeout(copyTimeout);
          evaluateActivity();
          copyTimeout = setTimeout(() => {
            isCopying = false;
            evaluateActivity();
          }, 5000);
          return;
        }

        // Upload / Attach file detection
        if (
          aria.includes('attach') ||
          aria.includes('upload') ||
          testId.includes('attach') ||
          testId.includes('file')
        ) {
          isUploading = true;
          clearTimeout(uploadTimeout);
          evaluateActivity();
          uploadTimeout = setTimeout(() => {
            isUploading = false;
            evaluateActivity();
          }, 8000);
        }
      },
      { passive: true, capture: true }
    );
  }

  // Evaluasi aktivitas saat ini secara berkala
  function evaluateActivity() {
    // 1. Jika AI sedang streaming respon, tetap catat waiting_ai walau kursor diam
    if (isAiGenerating()) {
      updateActivity('waiting_ai');
      return;
    }

    // 2. Jika kursor diam > 15 detik (tidak sedang tunggu streaming AI)
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      updateActivity('idle');
      return;
    }

    if (isTyping) {
      updateActivity('typing');
    } else if (isCopying) {
      updateActivity('copy_code');
    } else if (isUploading) {
      updateActivity('upload_file');
    } else {
      updateActivity('reading');
    }
  }

  // Listener perubahan status idle dari idle-detector
  if (window.GreatIdleDetector) {
    window.GreatIdleDetector.onStateChange((isIdle) => {
      if (isIdle && !isAiGenerating()) {
        updateActivity('idle');
      } else {
        evaluateActivity();
      }
    });
  }

  // Query berkala setiap 1.5 detik
  setInterval(evaluateActivity, 1500);

  // Respons ke background script jika ditanya status
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'QUERY_ACTIVITY') {
      evaluateActivity();
      sendResponse({
        activity: currentActivity,
        isIdle: window.GreatIdleDetector ? window.GreatIdleDetector.isIdle() : false,
      });
    }
  });

  // Inisialisasi
  setupTypingDetection();
  setupClickActions();
  evaluateActivity();

  console.log('[GreatTracker] ChatGPT Adapter Loaded.');
})();
