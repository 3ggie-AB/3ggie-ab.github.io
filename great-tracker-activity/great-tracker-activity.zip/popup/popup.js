/**
 * GreatTrackerActivity - Popup Dashboard Logic
 * Menampilkan status pemantauan real-time dan rincian waktu aktivitas hari ini.
 */

document.addEventListener('DOMContentLoaded', () => {
  const statusIndicator = document.getElementById('status-indicator');
  const statusBadgeTitle = document.getElementById('status-badge-title');
  const liveDetail = document.getElementById('live-detail');
  const totalFocusTimeEl = document.getElementById('total-focus-time');
  const currentDateTag = document.getElementById('current-date-tag');
  const breakdownList = document.getElementById('breakdown-list');
  const btnReset = document.getElementById('btn-reset');
  const btnExport = document.getElementById('btn-export');

  let cachedHistory = {};

  function updateDashboard() {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        statusBadgeTitle.textContent = 'Menghubungkan...';
        return;
      }

      cachedHistory = res.history || {};
      const today = res.todayKey;
      currentDateTag.textContent = today;

      // 1. Render Status Real-time
      statusIndicator.className = 'status-indicator';

      if (!res.isChromeWindowFocused) {
        statusIndicator.classList.add('paused');
        statusBadgeTitle.textContent = 'DIJEDA (APLIKASI LAIN AKTIF)';
        statusBadgeTitle.style.color = 'var(--accent-orange)';
        liveDetail.textContent = 'Timer dijeda karena jendela Chrome tidak sedang difokuskan.';
      } else if (res.isTabIdle) {
        statusIndicator.classList.add('paused');
        statusBadgeTitle.textContent = 'DIJEDA (KURSOR DIAM > 15s)';
        statusBadgeTitle.style.color = 'var(--accent-orange)';
        liveDetail.textContent = 'Timer dijeda otomatis saat kursor tidak bergerak.';
      } else if (res.isTracking && res.currentPlatform) {
        statusIndicator.classList.add('active');
        statusBadgeTitle.textContent = 'SEDANG MEMANTAU';
        statusBadgeTitle.style.color = 'var(--accent-emerald)';

        const platMeta = res.meta[res.currentPlatform] || {};
        const actMeta = platMeta.activities ? platMeta.activities[res.currentActivity] : null;
        const actLabel = actMeta ? `${actMeta.icon} ${actMeta.label}` : res.currentActivity;
        liveDetail.textContent = `${platMeta.name || res.currentPlatform} • ${actLabel}`;
      } else {
        statusBadgeTitle.textContent = 'STANDBY';
        statusBadgeTitle.style.color = 'var(--text-muted)';
        liveDetail.textContent = 'Buka tab ChatGPT, YouTube, atau GitHub untuk melacak.';
      }

      // 2. Render Breakdown Waktu Hari Ini
      const todayData = cachedHistory[today] || {};
      const platforms = ['chatgpt', 'youtube', 'github'];

      let grandTotalSeconds = 0;
      platforms.forEach((p) => {
        if (todayData[p] && todayData[p].total_seconds) {
          grandTotalSeconds += todayData[p].total_seconds;
        }
      });

      totalFocusTimeEl.textContent = formatDuration(grandTotalSeconds);

      // Render cards
      let html = '';
      let hasData = false;

      platforms.forEach((p) => {
        const platData = todayData[p];
        const pMeta = res.meta[p] || { name: p, color: '#38bdf8', activities: {} };
        const totalSec = platData ? platData.total_seconds || 0 : 0;

        if (totalSec > 0) {
          hasData = true;
          html += `
            <div class="platform-card">
              <div class="platform-header">
                <span class="platform-title" style="color:${pMeta.color};">
                  ${pMeta.icon || '🌐'} ${pMeta.name}
                </span>
                <span class="platform-total">${formatDuration(totalSec)}</span>
              </div>
              <div class="activity-list">
          `;

          // Sort activities by duration descending
          const actKeys = Object.keys(platData).filter((k) => k !== 'total_seconds');
          actKeys.sort((a, b) => (platData[b] || 0) - (platData[a] || 0));

          actKeys.forEach((actKey) => {
            const sec = platData[actKey] || 0;
            if (sec <= 0) return;
            const actInfo = pMeta.activities[actKey] || { label: actKey, icon: '•' };
            const percent = Math.min(100, Math.round((sec / totalSec) * 100));

            html += `
              <div class="activity-item">
                <div class="activity-meta">
                  <span class="activity-label">${actInfo.icon} ${actInfo.label}</span>
                  <span class="activity-duration">${formatDuration(sec)} (${percent}%)</span>
                </div>
                <div class="progress-track">
                  <div class="progress-fill" style="width: ${percent}%; background-color: ${pMeta.color};"></div>
                </div>
              </div>
            `;
          });

          html += `
              </div>
            </div>
          `;
        }
      });

      if (!hasData) {
        html = `
          <div class="empty-state">
            <p><strong>Belum ada catatan aktivitas hari ini.</strong></p>
            <p style="margin-top:6px; opacity:0.8;">Buka ChatGPT, YouTube, atau GitHub dan mulai beraktivitas. Timer otomatis berhenti jika kursor diam 15 detik.</p>
          </div>
        `;
      }

      breakdownList.innerHTML = html;
    });
  }

  // Update pertama kali & interval setiap 1 detik
  updateDashboard();
  const intervalId = setInterval(updateDashboard, 1000);
  window.addEventListener('unload', () => clearInterval(intervalId));

  // Tombol Reset Hari Ini
  btnReset.addEventListener('click', () => {
    if (confirm('Yakin ingin mereset catatan waktu pelacakan untuk hari ini?')) {
      chrome.runtime.sendMessage({ type: 'RESET_TODAY' }, () => {
        updateDashboard();
      });
    }
  });

  // Tombol Ekspor JSON
  btnExport.addEventListener('click', () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(cachedHistory, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `great_tracker_history_${getTodayKey()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  });
});
