/**
 * GreatTrackerActivity - Core Idle & Focus Detector
 * Mendeteksi kursor diam (>15 detik), tidak ada scroll/ketikan, serta saat jendela kehilangan fokus
 */

(function () {
  if (window.__greatIdleDetectorInit) return;
  window.__greatIdleDetectorInit = true;

  const IDLE_THRESHOLD_MS = 15000; // 15 detik batas kursor diam
  let lastActivityTime = Date.now();
  let isCurrentlyIdle = false;
  let isWindowFocused = document.hasFocus() && !document.hidden;
  const listeners = [];

  function notifyChange() {
    const idleState = isCurrentlyIdle || !isWindowFocused;
    listeners.forEach((callback) => {
      try {
        callback(idleState);
      } catch (e) {
        console.error('[GreatTracker IdleDetector] Error in listener:', e);
      }
    });

    // Kirim sinyal ke background service worker
    try {
      chrome.runtime.sendMessage({
        type: 'IDLE_STATE_CHANGED',
        isIdle: idleState,
        reason: !isWindowFocused ? 'window_blurred' : 'cursor_inactive',
        timestamp: Date.now(),
      });
    } catch (_) {}
  }

  function registerUserAction() {
    lastActivityTime = Date.now();
    if (isCurrentlyIdle) {
      isCurrentlyIdle = false;
      notifyChange();
    }
  }

  // Event listener untuk mendeteksi interaksi fisik pengguna
  const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'wheel', 'touchstart', 'click'];
  let throttleTimer = null;

  events.forEach((eventName) => {
    window.addEventListener(
      eventName,
      () => {
        if (!throttleTimer) {
          registerUserAction();
          throttleTimer = setTimeout(() => {
            throttleTimer = null;
          }, 400);
        }
      },
      { passive: true, capture: true }
    );
  });

  // Deteksi saat pengguna beralih tab atau beralih ke aplikasi lain
  window.addEventListener('blur', () => {
    isWindowFocused = false;
    notifyChange();
  });

  window.addEventListener('focus', () => {
    isWindowFocused = true;
    registerUserAction();
    notifyChange();
  });

  document.addEventListener('visibilitychange', () => {
    isWindowFocused = !document.hidden && document.hasFocus();
    if (isWindowFocused) registerUserAction();
    notifyChange();
  });

  // Timer interval setiap 1 detik untuk mengecek apakah sudah melewati 15 detik kursor diam
  setInterval(() => {
    const elapsed = Date.now() - lastActivityTime;
    const shouldBeIdle = elapsed >= IDLE_THRESHOLD_MS;

    if (shouldBeIdle !== isCurrentlyIdle) {
      isCurrentlyIdle = shouldBeIdle;
      notifyChange();
    }
  }, 1000);

  // Expose ke window untuk dipakai adapter
  window.GreatIdleDetector = {
    isIdle: () => isCurrentlyIdle || !isWindowFocused,
    onStateChange: (fn) => listeners.push(fn),
    recordAction: registerUserAction,
  };

  console.log('[GreatTracker] Idle detector initialized with 15s threshold.');
})();
