/**
 * GreatTrackerActivity - Storage Manager
 * Mengelola struktur data pelacakan aktivitas harian di chrome.storage.local
 */

const ACTIVITY_META = {
  chatgpt: {
    name: 'ChatGPT',
    color: '#10a37f',
    icon: '🤖',
    activities: {
      reading: { label: 'Membaca respons AI', icon: '📖' },
      typing: { label: 'Mengetik prompt', icon: '⌨️' },
      waiting_ai: { label: 'Menunggu AI streaming', icon: '⏳' },
      copy_code: { label: 'Menyalin kode (Copy code)', icon: '📋' },
      upload_file: { label: 'Mengunggah berkas', icon: '📎' },
      idle: { label: 'Diam / Jeda', icon: '⏸️' },
    },
  },
  youtube: {
    name: 'YouTube',
    color: '#ff0000',
    icon: '▶️',
    activities: {
      watching_video: { label: 'Menonton video', icon: '🎬' },
      search_video: { label: 'Mencari video', icon: '🔍' },
      comments: { label: 'Membaca / menulis komentar', icon: '💬' },
      shorts: { label: 'Menonton YouTube Shorts', icon: '📱' },
      browsing: { label: 'Jelajah beranda / channel', icon: '🧭' },
      idle: { label: 'Diam / Jeda', icon: '⏸️' },
    },
  },
  github: {
    name: 'GitHub',
    color: '#2dba4e',
    icon: '🐙',
    activities: {
      reading_readme: { label: 'Membaca README repo', icon: '📄' },
      coding: { label: 'Coding / Review code', icon: '💻' },
      view_issue: { label: 'Melihat Issue', icon: '🐞' },
      pull_request: { label: 'Meninjau Pull Request', icon: '🔀' },
      browsing: { label: 'Jelajah repositori', icon: '📂' },
      idle: { label: 'Diam / Jeda', icon: '⏸️' },
    },
  },
};

function getTodayKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

async function getStorageData(key = null) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (res) => resolve(res));
  });
}

async function setStorageData(obj) {
  return new Promise((resolve) => {
    chrome.storage.local.set(obj, () => resolve(true));
  });
}

/**
 * Catat durasi detik ke platform & aktivitas spesifik
 */
async function recordActivityTime(platform, activity, seconds = 1) {
  if (!platform || !activity || seconds <= 0) return;
  const dateKey = getTodayKey();
  const data = await getStorageData('tracking_history');
  const history = data.tracking_history || {};

  if (!history[dateKey]) history[dateKey] = {};
  if (!history[dateKey][platform]) history[dateKey][platform] = { total_seconds: 0 };

  const currentSec = history[dateKey][platform][activity] || 0;
  history[dateKey][platform][activity] = currentSec + seconds;
  history[dateKey][platform].total_seconds = (history[dateKey][platform].total_seconds || 0) + seconds;

  await setStorageData({ tracking_history: history });
}

/**
 * Format detik ke representasi jam, menit, detik yang ramah
 */
function formatDuration(totalSeconds) {
  if (!totalSeconds || totalSeconds <= 0) return '0 dtk';
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const parts = [];
  if (hours > 0) parts.push(`${hours} jam`);
  if (minutes > 0) parts.push(`${minutes} mnt`);
  if (seconds > 0 && hours === 0) parts.push(`${seconds} dtk`);

  return parts.join(' ') || '0 dtk';
}

// Export untuk lingkungan Node/ES jika diperlukan, atau attach ke global/self
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ACTIVITY_META,
    getTodayKey,
    getStorageData,
    setStorageData,
    recordActivityTime,
    formatDuration,
  };
}
