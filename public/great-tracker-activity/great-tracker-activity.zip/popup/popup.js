/**
 * GreatTrackerActivity - Telemetry Statistic Bar Dashboard Logic
 * Minimalist, developer-grade performance & focus distribution tracker
 */

document.addEventListener('DOMContentLoaded', () => {
  const livePill = document.getElementById('live-pill');
  const liveText = document.getElementById('live-text');
  const tickerValue = document.getElementById('ticker-value');
  const totalFocusTimeEl = document.getElementById('total-focus-time');
  const currentDateTag = document.getElementById('current-date-tag');
  const stackedBar = document.getElementById('stacked-distribution-bar');
  const stackedLegend = document.getElementById('stacked-legend');
  const statsList = document.getElementById('stats-list');
  const domainCount = document.getElementById('domain-count');
  const btnReset = document.getElementById('btn-reset');
  const btnExport = document.getElementById('btn-export');

  const PALETTE = [
    '#10b981', // emerald
    '#06b6d4', // cyan
    '#8b5cf6', // violet
    '#f59e0b', // amber
    '#3b82f6', // blue
    '#ec4899', // pink
    '#14b8a6', // teal
    '#f97316', // orange
    '#a855f7', // purple
    '#64748b', // slate
  ];

  const KNOWN_COLORS = {
    github: '#10b981',
    chatgpt: '#06b6d4',
    youtube: '#f43f5e',
  };

  const KNOWN_LABELS = {
    chatgpt: {
      reading: 'Reading response',
      typing: 'Prompt input',
      waiting_ai: 'AI streaming',
      copy_code: 'Copy code snippet',
      upload_file: 'File upload',
      idle: 'Idle',
    },
    youtube: {
      watching_video: 'Video playback',
      search_video: 'Search / browse',
      comments: 'Comments',
      shorts: 'Shorts feed',
      browsing: 'Feed navigation',
      idle: 'Idle',
    },
    github: {
      reading_readme: 'README view',
      coding: 'Code / Diff viewer',
      view_issue: 'Issue tracker',
      pull_request: 'PR review',
      browsing: 'Repo navigation',
      idle: 'Idle',
    },
  };

  let cachedHistory = {};

  function getColor(platform, index) {
    if (KNOWN_COLORS[platform]) return KNOWN_COLORS[platform];
    return PALETTE[index % PALETTE.length];
  }

  function formatTime(totalSec) {
    if (!totalSec || totalSec <= 0) return '00s';
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;

    if (h > 0) {
      return `${String(h).padStart(2, '0')}h ${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
    }
    if (m > 0) {
      return `${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
    }
    return `${String(s).padStart(2, '0')}s`;
  }

  function formatCompactTime(sec) {
    if (!sec || sec <= 0) return '0s';
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;

    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  }

  function getActivityLabel(platform, actKey) {
    if (KNOWN_LABELS[platform] && KNOWN_LABELS[platform][actKey]) {
      return KNOWN_LABELS[platform][actKey];
    }
    return actKey.replace(/_/g, ' ');
  }

  function updateDashboard() {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        livePill.className = 'live-pill';
        liveText.textContent = 'OFFLINE';
        tickerValue.textContent = 'Connecting to background telemetry...';
        return;
      }

      cachedHistory = res.history || {};
      const today = res.todayKey;
      currentDateTag.textContent = today;

      // 1. Live Session Telemetry Indicator
      if (!res.isChromeWindowFocused) {
        livePill.className = 'live-pill paused';
        liveText.textContent = 'BLURRED';
        tickerValue.textContent = 'Inactive (External application focused)';
      } else if (res.isTracking && res.currentPlatform) {
        livePill.className = 'live-pill active';
        liveText.textContent = 'TRACKING';
        const actClean = getActivityLabel(res.currentPlatform, res.currentActivity || 'reading');
        tickerValue.textContent = `${res.currentPlatform} [${actClean}]`;
      } else if (res.isTabIdle) {
        livePill.className = 'live-pill paused';
        liveText.textContent = 'IDLE';
        tickerValue.textContent = 'Paused (Cursor stationary > 15s)';
      } else {
        livePill.className = 'live-pill';
        liveText.textContent = 'STANDBY';
        tickerValue.textContent = 'Open any web tab to start recording';
      }

      // 2. Compute Metrics & Breakdown
      const todayData = cachedHistory[today] || {};
      const platformKeys = Object.keys(todayData).filter(
        (p) => todayData[p] && todayData[p].total_seconds > 0
      );

      platformKeys.sort((a, b) => (todayData[b].total_seconds || 0) - (todayData[a].total_seconds || 0));

      let grandTotalSeconds = 0;
      platformKeys.forEach((p) => {
        grandTotalSeconds += todayData[p].total_seconds;
      });

      totalFocusTimeEl.textContent = formatTime(grandTotalSeconds);
      domainCount.textContent = `${platformKeys.length} Domain${platformKeys.length === 1 ? '' : 's'}`;

      // 3. Multi-Segment Stacked Distribution Bar
      if (grandTotalSeconds > 0 && platformKeys.length > 0) {
        let stackedHtml = '';
        let legendHtml = '';

        platformKeys.forEach((p, idx) => {
          const sec = todayData[p].total_seconds || 0;
          const pct = ((sec / grandTotalSeconds) * 100).toFixed(1);
          const color = getColor(p, idx);

          stackedHtml += `<div class="stacked-segment" style="width: ${pct}%; background: ${color};" title="${p}: ${pct}% (${formatCompactTime(sec)})"></div>`;
          legendHtml += `
            <div class="legend-item">
              <span class="legend-dot" style="background: ${color};"></span>
              <span>${p}</span>
              <span class="legend-pct">${pct}%</span>
            </div>
          `;
        });

        stackedBar.innerHTML = stackedHtml;
        stackedLegend.innerHTML = legendHtml;
      } else {
        stackedBar.innerHTML = '<div class="stacked-segment-empty"></div>';
        stackedLegend.innerHTML = '<span style="font-size:10px; color:var(--text-muted);">No distribution data</span>';
      }

      // 4. Domain Statistic Breakdown Bars
      if (platformKeys.length > 0) {
        let listHtml = '';

        platformKeys.forEach((p, idx) => {
          const platData = todayData[p];
          const totalSec = platData.total_seconds || 0;
          const domainPct = grandTotalSeconds > 0 ? ((totalSec / grandTotalSeconds) * 100).toFixed(1) : 0;
          const color = getColor(p, idx);

          // Get micro activities
          const actKeys = Object.keys(platData).filter((k) => k !== 'total_seconds');
          actKeys.sort((a, b) => (platData[b] || 0) - (platData[a] || 0));

          let microRowsHtml = '';
          if (actKeys.length > 1 || (actKeys.length === 1 && actKeys[0] !== 'reading')) {
            actKeys.forEach((actKey) => {
              const actSec = platData[actKey] || 0;
              if (actSec <= 0) return;
              const actPct = totalSec > 0 ? Math.round((actSec / totalSec) * 100) : 0;
              const actName = getActivityLabel(p, actKey);

              microRowsHtml += `
                <div class="micro-row">
                  <div class="micro-meta">
                    <span class="micro-label">${actName}</span>
                    <span class="micro-val">${formatCompactTime(actSec)} · ${actPct}%</span>
                  </div>
                  <div class="micro-bar-track">
                    <div class="micro-bar-fill" style="width: ${actPct}%; background: ${color};"></div>
                  </div>
                </div>
              `;
            });
          }

          listHtml += `
            <div class="stats-card">
              <div class="stats-card-header">
                <div class="domain-identity">
                  <span class="domain-indicator" style="background: ${color};"></span>
                  <span class="domain-name" title="${p}">${p}</span>
                </div>
                <div class="stats-metrics">
                  <span class="stats-time">${formatCompactTime(totalSec)}</span>
                  <span class="stats-percent">${domainPct}%</span>
                </div>
              </div>

              <!-- Main Domain Statistic Bar -->
              <div class="domain-bar-track">
                <div class="domain-bar-fill" style="width: ${domainPct}%; background: ${color};"></div>
              </div>

              <!-- Micro Breakdown (Sub-Statistic Bars) -->
              ${microRowsHtml ? `<div class="micro-activity-group">${microRowsHtml}</div>` : ''}
            </div>
          `;
        });

        statsList.innerHTML = listHtml;
      } else {
        statsList.innerHTML = `
          <div class="empty-telemetry">
            <span class="empty-title">NO ACTIVITY LOGGED TODAY</span>
            <p class="empty-desc">Buka website apa saja untuk mulai mencatat. Timer otomatis berhenti saat kursor diam &gt; 15s atau beralih aplikasi.</p>
          </div>
        `;
      }
    });
  }

  // Loop update setiap 1 detik
  updateDashboard();
  const intervalId = setInterval(updateDashboard, 1000);
  window.addEventListener('unload', () => clearInterval(intervalId));

  // Reset Button
  btnReset.addEventListener('click', () => {
    if (confirm('Reset seluruh data telemetri aktivitas hari ini?')) {
      chrome.runtime.sendMessage({ type: 'RESET_TODAY' }, () => {
        updateDashboard();
      });
    }
  });

  // Export JSON Button
  btnExport.addEventListener('click', () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(cachedHistory, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `great_tracker_${getTodayKey()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  });
});
