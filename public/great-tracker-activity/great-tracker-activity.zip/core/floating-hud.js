/**
 * GreatTrackerActivity - Floating Live Telemetry HUD
 * Menampilkan floating timer detik real-time langsung di pojok halaman web
 * Berjalan di Shadow DOM agar tidak bertabrakan dengan CSS website asli.
 */

(function () {
  // Hanya inisialisasi pada top-level window (bukan di dalam iframe)
  if (window !== window.top) return;
  if (window.__greatTrackerHudInit) return;
  window.__greatTrackerHudInit = true;

  // Cek apakah halaman adalah halaman biasa (bukan internal)
  const host = window.location.hostname.toLowerCase();
  const cleanHost = host.replace(/^www\./, '');

  let sessionSeconds = 0;
  let accumulatedTicks = 0;
  let isHudMinimized = false;
  let isHudHidden = false;
  let currentActivity = 'reading';
  let isCurrentlyIdle = false;

  // Cek preferensi user dari storage
  try {
    chrome.storage.local.get(['hud_hidden', 'hud_minimized'], (res) => {
      if (res) {
        if (res.hud_hidden === true) {
          isHudHidden = true;
          container.style.display = 'none';
        }
        if (res.hud_minimized === true) {
          toggleMinimize(true);
        }
      }
    });
  } catch (_) {}

  // 1. Buat Host Element & Shadow Root
  const hostEl = document.createElement('div');
  hostEl.id = 'great-tracker-hud-host';
  hostEl.style.cssText = 'all: initial; position: fixed; z-index: 2147483647; pointer-events: none;';
  document.documentElement.appendChild(hostEl);

  const shadow = hostEl.attachShadow({ mode: 'closed' });

  // 2. CSS di dalam Shadow Root (Developer-Grade Telemetry Theme)
  const style = document.createElement('style');
  style.textContent = `
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      -webkit-font-smoothing: antialiased;
    }

    .gta-hud-container {
      position: fixed;
      bottom: 18px;
      right: 18px;
      pointer-events: auto;
      background: #09090b;
      color: #fafafa;
      border: 1px solid #27272a;
      border-radius: 6px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.65), 0 2px 6px rgba(0, 0, 0, 0.4);
      user-select: none;
      transition: opacity 0.2s ease, transform 0.2s ease;
      font-size: 11px;
      line-height: 1.4;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      min-width: 250px;
      max-width: 320px;
    }

    .gta-hud-header {
      background: #121215;
      padding: 5px 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #1f1f23;
      cursor: grab;
    }

    .gta-hud-header:active {
      cursor: grabbing;
    }

    .gta-brand-tag {
      display: flex;
      align-items: center;
      gap: 6px;
      font-weight: 700;
      font-size: 10px;
      color: #a1a1aa;
      letter-spacing: 0.5px;
    }

    .gta-pulse-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: #10b981;
      box-shadow: 0 0 6px #10b981;
      display: inline-block;
      transition: background 0.3s ease, box-shadow 0.3s ease;
    }

    .gta-pulse-dot.paused {
      background: #f59e0b;
      box-shadow: 0 0 6px #f59e0b;
    }

    .gta-pulse-dot.blurred {
      background: #ef4444;
      box-shadow: 0 0 6px #ef4444;
    }

    .gta-controls {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .gta-btn {
      background: transparent;
      border: none;
      color: #71717a;
      cursor: pointer;
      font-size: 10px;
      padding: 2px 4px;
      border-radius: 3px;
      line-height: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .gta-btn:hover {
      background: #27272a;
      color: #fafafa;
    }

    .gta-hud-body {
      padding: 8px 10px;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .gta-timer-row {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 8px;
    }

    .gta-timer-time {
      font-size: 18px;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: -0.5px;
      font-variant-numeric: tabular-nums;
    }

    .gta-status-badge {
      font-size: 9px;
      font-weight: 700;
      padding: 1px 5px;
      border-radius: 3px;
      border: 1px solid #27272a;
      color: #10b981;
      background: rgba(16, 185, 129, 0.1);
      letter-spacing: 0.5px;
    }

    .gta-status-badge.paused {
      color: #f59e0b;
      background: rgba(245, 158, 11, 0.1);
      border-color: rgba(245, 158, 11, 0.3);
    }

    .gta-status-badge.blurred {
      color: #ef4444;
      background: rgba(239, 68, 68, 0.1);
      border-color: rgba(239, 68, 68, 0.3);
    }

    .gta-telemetry-meta {
      font-size: 10px;
      color: #71717a;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-top: 2px;
      border-top: 1px dashed #1f1f23;
    }

    .gta-domain-name {
      color: #a1a1aa;
      font-weight: 600;
      max-width: 160px;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .gta-activity-tag {
      color: #06b6d4;
    }

    /* Minimized Style (Floating Compact Pill) */
    .gta-hud-container.minimized {
      min-width: auto;
      max-width: none;
      flex-direction: row;
      align-items: center;
      padding: 4px 8px;
      gap: 8px;
      border-radius: 20px;
      cursor: grab;
    }

    .gta-hud-container.minimized .gta-hud-header {
      background: transparent;
      padding: 0;
      border: none;
    }

    .gta-hud-container.minimized .gta-hud-body {
      padding: 0;
      flex-direction: row;
      align-items: center;
      gap: 6px;
    }

    .gta-hud-container.minimized .gta-timer-time {
      font-size: 12px;
      font-weight: 700;
    }

    .gta-hud-container.minimized .gta-telemetry-meta,
    .gta-hud-container.minimized .gta-status-badge {
      display: none;
    }
  `;
  shadow.appendChild(style);

  // 3. HTML Structure
  const container = document.createElement('div');
  container.className = 'gta-hud-container';
  container.innerHTML = `
    <div class="gta-hud-header" id="gta-drag-handle">
      <div class="gta-brand-tag">
        <span class="gta-pulse-dot" id="gta-dot"></span>
        <span>GTA MONITOR</span>
      </div>
      <div class="gta-controls">
        <button class="gta-btn" id="gta-btn-min" title="Kecilkan/Besarkan Timer">—</button>
        <button class="gta-btn" id="gta-btn-close" title="Sembunyikan Timer (Dapat diaktifkan di popup)">✕</button>
      </div>
    </div>
    <div class="gta-hud-body">
      <div class="gta-timer-row">
        <span class="gta-timer-time" id="gta-time">00:00:00</span>
        <span class="gta-status-badge" id="gta-badge">ACTIVE</span>
      </div>
      <div class="gta-telemetry-meta">
        <span class="gta-domain-name" id="gta-domain" title="${cleanHost}">${cleanHost}</span>
        <span class="gta-activity-tag" id="gta-activity">reading</span>
      </div>
    </div>
  `;
  shadow.appendChild(container);

  const dotEl = container.querySelector('#gta-dot');
  const timeEl = container.querySelector('#gta-time');
  const badgeEl = container.querySelector('#gta-badge');
  const domainEl = container.querySelector('#gta-domain');
  const activityEl = container.querySelector('#gta-activity');
  const dragHandle = container.querySelector('#gta-drag-handle');
  const btnMin = container.querySelector('#gta-btn-min');
  const btnClose = container.querySelector('#gta-btn-close');

  function formatDigital(totalSec) {
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  function toggleMinimize(forceState = null) {
    isHudMinimized = forceState !== null ? forceState : !isHudMinimized;
    if (isHudMinimized) {
      container.classList.add('minimized');
      btnMin.textContent = '▢';
    } else {
      container.classList.remove('minimized');
      btnMin.textContent = '—';
    }
    try {
      chrome.storage.local.set({ hud_minimized: isHudMinimized });
    } catch (_) {}
  }

  btnMin.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleMinimize();
  });

  btnClose.addEventListener('click', (e) => {
    e.stopPropagation();
    container.style.display = 'none';
    isHudHidden = true;
    try {
      chrome.storage.local.set({ hud_hidden: true });
    } catch (_) {}
  });

  // 4. Draggable Floating Logic
  let isDragging = false;
  let startX = 0, startY = 0, initialLeft = 0, initialTop = 0;

  function onMouseDown(e) {
    if (e.target === btnMin || e.target === btnClose) return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;

    const rect = container.getBoundingClientRect();
    container.style.bottom = 'auto';
    container.style.right = 'auto';
    container.style.left = `${rect.left}px`;
    container.style.top = `${rect.top}px`;
    initialLeft = rect.left;
    initialTop = rect.top;

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  }

  function onMouseMove(e) {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    container.style.left = `${Math.max(8, Math.min(window.innerWidth - container.offsetWidth - 8, initialLeft + dx))}px`;
    container.style.top = `${Math.max(8, Math.min(window.innerHeight - container.offsetHeight - 8, initialTop + dy))}px`;
  }

  function onMouseUp() {
    isDragging = false;
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
  }

  dragHandle.addEventListener('mousedown', onMouseDown);
  container.addEventListener('mousedown', (e) => {
    if (isHudMinimized) onMouseDown(e);
  });

  // 5. Time Ticking & State Engine (Runs 100% Reliably in Webpage DOM!)
  function flushTicks() {
    if (accumulatedTicks <= 0) return;
    const delta = accumulatedTicks;
    accumulatedTicks = 0;

    try {
      chrome.runtime.sendMessage({
        type: 'RECORD_TICKS',
        platform: cleanHost,
        activity: currentActivity,
        seconds: delta,
      });
    } catch (_) {}
  }

  setInterval(() => {
    // Cek fokus dokumen & kursor diam
    const isDocFocused = document.hasFocus();
    const isDetectorIdle = window.GreatIdleDetector ? window.GreatIdleDetector.isIdle() : false;

    // Spesial YouTube / ChatGPT: jika video aktif atau AI sedang streaming, jangan idle
    const isVideoPlaying = () => {
      const v = document.querySelector('video');
      return v && !v.paused && !v.ended && v.readyState > 2;
    };
    const isAiGenerating = () => {
      return !!document.querySelector('button[data-testid="stop-button"], button[aria-label*="Stop"], .result-streaming');
    };

    const isExempt = (cleanHost.includes('youtube') && isVideoPlaying()) ||
                     (cleanHost.includes('chatgpt') && isAiGenerating());

    const isTracking = isDocFocused && (!isDetectorIdle || isExempt);

    // Update UI Status
    if (!isDocFocused) {
      dotEl.className = 'gta-pulse-dot blurred';
      badgeEl.className = 'gta-status-badge blurred';
      badgeEl.textContent = 'BLURRED';
    } else if (isTracking) {
      dotEl.className = 'gta-pulse-dot';
      badgeEl.className = 'gta-status-badge';
      badgeEl.textContent = 'ACTIVE';

      // Increment live second timer
      sessionSeconds++;
      accumulatedTicks++;
      timeEl.textContent = formatDigital(sessionSeconds);
    } else {
      dotEl.className = 'gta-pulse-dot paused';
      badgeEl.className = 'gta-status-badge paused';
      badgeEl.textContent = 'IDLE (15s)';
    }

    // Flush batch ticks ke background setiap 5 detik agar service worker tetap sinkron
    if (accumulatedTicks >= 5) {
      flushTicks();
    }
  }, 1000);

  // Sync saat tab akan di-close atau dipindah
  window.addEventListener('beforeunload', flushTicks);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) flushTicks();
  });

  // Dengarkan pesan dari adapter jika ada perubahan aktivitas
  window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'GTA_ACTIVITY_UPDATE') {
      currentActivity = event.data.activity || 'reading';
      activityEl.textContent = currentActivity;
    }
  });

  // Dengarkan pesan dari popup untuk show/hide HUD
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'TOGGLE_HUD') {
      if (isHudHidden) {
        container.style.display = 'flex';
        isHudHidden = false;
        chrome.storage.local.set({ hud_hidden: false });
      } else {
        container.style.display = 'none';
        isHudHidden = true;
        chrome.storage.local.set({ hud_hidden: true });
      }
      sendResponse({ isHidden: isHudHidden });
    }
    if (msg.type === 'GET_HUD_STATE') {
      sendResponse({ isHidden: isHudHidden, sessionSeconds });
    }
  });

  console.log('[GreatTracker] Floating Telemetry HUD initialized for:', cleanHost);
})();
