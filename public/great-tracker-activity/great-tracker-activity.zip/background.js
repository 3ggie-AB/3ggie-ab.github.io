/**
 * GreatTrackerActivity - Background Service Worker
 * Mengatur Master Timer, sinkronisasi fokus jendela/aplikasi Chrome, dan penyimpanan harian.
 */

// Import Storage helpers (menggunakan importScripts di Service Worker Manifest V3)
importScripts('core/storage.js');

let activeTabId = null;
let activeWindowId = chrome.windows.WINDOW_ID_NONE;
let isChromeWindowFocused = true;
let isTabIdle = false;
let currentPlatform = null;
let currentActivity = null;
let currentTabUrl = '';

// Inisialisasi status jendela saat service worker aktif
chrome.windows.getCurrent((win) => {
  if (win) {
    activeWindowId = win.id;
    isChromeWindowFocused = win.focused;
  }
});

// Deteksi saat pengguna berpindah ke aplikasi lain di luar Chrome (VS Code, Terminal, dll)
chrome.windows.onFocusChanged.addListener((windowId) => {
  activeWindowId = windowId;
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // Jendela Chrome kehilangan fokus -> Pindah ke aplikasi luar
    isChromeWindowFocused = false;
    console.log('[GreatTracker] Chrome blur: Pengguna pindah ke aplikasi luar. Timer di-PAUSE.');
  } else {
    // Pengguna kembali ke Chrome
    isChromeWindowFocused = true;
    console.log('[GreatTracker] Chrome focus: Pengguna kembali ke Chrome.');
    syncActiveTab();
  }
});

// Deteksi saat pengguna berpindah tab
chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
  activeTabId = tabId;
  activeWindowId = windowId;
  syncActiveTab();
});

// Deteksi saat URL tab berubah
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId === activeTabId && changeInfo.url) {
    syncActiveTab();
  }
});

function detectPlatform(url) {
  if (!url) return null;
  try {
    const parsed = new URL(url);
    // Hanya lacak laman web HTTP dan HTTPS (abaikan chrome://, extension://, about:, file://, dll)
    if (!['http:', 'https:'].includes(parsed.protocol)) return null;

    const host = parsed.hostname.toLowerCase();
    if (host.includes('chatgpt.com')) return 'chatgpt';
    if (host.includes('youtube.com')) return 'youtube';
    if (host.includes('github.com')) return 'github';

    // Untuk domain lainnya (seperti dashboard it syntax dev), simpan sebagai nama domain bersih
    return host.replace(/^www\./, '');
  } catch (_) {}
  return null;
}

function syncActiveTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs.length > 0) {
      const tab = tabs[0];
      activeTabId = tab.id;
      currentTabUrl = tab.url || '';
      const detected = detectPlatform(currentTabUrl);

      if (detected !== currentPlatform) {
        currentPlatform = detected;
        currentActivity = detected ? 'reading' : null; // default baseline
      }

      // Tanya content script tentang aktivitas terkini
      if (currentPlatform && activeTabId) {
        chrome.tabs.sendMessage(activeTabId, { type: 'QUERY_ACTIVITY' }, (response) => {
          if (chrome.runtime.lastError) return;
          if (response && response.activity) {
            currentActivity = response.activity;
            isTabIdle = !!response.isIdle;
          }
        });
      }
    } else {
      currentPlatform = null;
      currentActivity = null;
    }
  });
}

function updateBadge() {
  getStorageData('tracking_history').then((data) => {
    const today = getTodayKey();
    const todayData = (data.tracking_history && data.tracking_history[today]) || {};
    let totalSec = 0;
    Object.keys(todayData).forEach((p) => {
      totalSec += todayData[p].total_seconds || 0;
    });
    const mins = Math.floor(totalSec / 60);
    const badgeText = mins > 0 ? (mins > 999 ? '999+' : `${mins}m`) : '';
    chrome.action.setBadgeText({ text: badgeText });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
  });
}

// Inisialisasi badge saat start
updateBadge();

// Listener pesan dari content script dan popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Perekaman waktu dari Content Script Floating Engine
  if (message.type === 'RECORD_TICKS') {
    const platform = message.platform;
    const activity = message.activity || currentActivity || 'reading';
    const seconds = message.seconds || 1;
    if (platform && activity && seconds > 0) {
      currentPlatform = platform;
      currentActivity = activity;
      recordActivityTime(platform, activity, seconds);
      updateBadge();
    }
    sendResponse({ recorded: true });
    return true;
  }
  if (message.type === 'ACTIVITY_CHANGED') {
    // Pastikan pesan datang dari tab yang sedang aktif
    if (sender.tab && sender.tab.id === activeTabId) {
      currentPlatform = message.platform || detectPlatform(sender.tab.url);
      currentActivity = message.activity;
      console.log(`[GreatTracker] Aktivitas: ${currentPlatform} -> ${currentActivity}`);
    }
    sendResponse({ received: true });
    return true;
  }

  if (message.type === 'IDLE_STATE_CHANGED') {
    if (sender.tab && sender.tab.id === activeTabId) {
      isTabIdle = message.isIdle;
      console.log(`[GreatTracker] Status Idle Tab: ${isTabIdle ? 'PAUSED' : 'RESUMED'} (${message.reason})`);
    }
    sendResponse({ received: true });
    return true;
  }

  if (message.type === 'GET_STATUS') {
    // Kirim snapshot status real-time untuk popup
    const isVideoOrAi =
      (currentPlatform === 'youtube' && (currentActivity === 'watching_video' || currentActivity === 'shorts')) ||
      (currentPlatform === 'chatgpt' && currentActivity === 'waiting_ai');

    const isTracking =
      isChromeWindowFocused &&
      (!isTabIdle || isVideoOrAi) &&
      currentPlatform &&
      currentActivity &&
      currentActivity !== 'idle';

    getStorageData('tracking_history').then((data) => {
      sendResponse({
        isTracking,
        isChromeWindowFocused,
        isTabIdle: isVideoOrAi ? false : isTabIdle,
        currentPlatform,
        currentActivity,
        todayKey: getTodayKey(),
        history: data.tracking_history || {},
        meta: ACTIVITY_META,
      });
    });
    return true; // Asynchronous sendResponse
  }

  if (message.type === 'RESET_TODAY') {
    const today = getTodayKey();
    getStorageData('tracking_history').then(async (data) => {
      const history = data.tracking_history || {};
      delete history[today];
      await setStorageData({ tracking_history: history });
      sendResponse({ success: true });
    });
    return true;
  }
});
