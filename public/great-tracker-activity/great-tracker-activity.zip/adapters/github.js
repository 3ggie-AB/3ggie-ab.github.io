/**
 * GreatTrackerActivity - GitHub Domain Adapter
 * Mendeteksi aktivitas mikro: Membaca README, Coding/Review code, Melihat Issue, Meninjau Pull Request
 */

(function () {
  const PLATFORM = 'github';
  let currentActivity = 'browsing';

  function updateActivity(newActivity) {
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      newActivity = 'idle';
    }

    if (currentActivity !== newActivity) {
      currentActivity = newActivity;
      window.postMessage({ type: 'GTA_ACTIVITY_UPDATE', activity: currentActivity }, '*');
      try {
        chrome.runtime.sendMessage({
          type: 'ACTIVITY_CHANGED',
          platform: PLATFORM,
          activity: currentActivity,
        });
      } catch (_) {}
    }
  }

  function isReadingReadme() {
    const readme = document.querySelector('#readme, article.markdown-body, [data-target="readme.content"]');
    if (!readme) return false;

    const rect = readme.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;

    // README dianggap sedang dibaca jika setidaknya separuh area layar menampilkan README
    return rect.top < windowHeight * 0.75 && rect.bottom > windowHeight * 0.25;
  }

  function isCodingOrEditing() {
    const path = window.location.pathname;
    if (path.includes('/edit/') || path.includes('/new/') || path.includes('/blob/')) return true;

    // Deteksi Monaco editor, textarea kode, atau view code diff
    const codeEditor = document.querySelector('.monaco-editor, .react-blob-view, .blob-wrapper, textarea.file-editor-textarea');
    return !!codeEditor;
  }

  function isIssuePage() {
    const path = window.location.pathname;
    return path.includes('/issues') && !path.includes('/pull');
  }

  function isPullRequestPage() {
    const path = window.location.pathname;
    return path.includes('/pull/') || path.includes('/pulls');
  }

  function evaluateActivity() {
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      updateActivity('idle');
      return;
    }

    // 1. Issue
    if (isIssuePage()) {
      updateActivity('view_issue');
      return;
    }

    // 2. Pull Request
    if (isPullRequestPage()) {
      updateActivity('pull_request');
      return;
    }

    // 3. Membaca README (prioritas jika user sedang scroll ke area README di repo)
    if (isReadingReadme()) {
      updateActivity('reading_readme');
      return;
    }

    // 4. Coding / File view
    if (isCodingOrEditing()) {
      updateActivity('coding');
      return;
    }

    // 5. Jelajah repositori umum
    updateActivity('browsing');
  }

  // Listener idle
  if (window.GreatIdleDetector) {
    window.GreatIdleDetector.onStateChange((isIdle) => {
      if (isIdle) {
        updateActivity('idle');
      } else {
        evaluateActivity();
      }
    });
  }

  // Evaluasi saat user scroll atau navigasi SPA GitHub
  window.addEventListener('scroll', evaluateActivity, { passive: true });
  document.addEventListener('turbo:load', evaluateActivity, { passive: true });
  document.addEventListener('pjax:end', evaluateActivity, { passive: true });

  setInterval(evaluateActivity, 1500);

  // Respons ke background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'QUERY_ACTIVITY') {
      evaluateActivity();
      sendResponse({
        activity: currentActivity,
        isIdle: window.GreatIdleDetector ? window.GreatIdleDetector.isIdle() : false,
      });
    }
  });

  evaluateActivity();

  console.log('[GreatTracker] GitHub Adapter Loaded.');
})();
