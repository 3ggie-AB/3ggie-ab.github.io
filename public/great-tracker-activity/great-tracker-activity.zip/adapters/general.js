/**
 * GreatTrackerActivity - Universal General Domain Adapter
 * Melacak aktivitas produktivitas mikro (Membaca, Mengetik, Scrolling) di semua domain web
 */

(function () {
  const host = window.location.hostname.toLowerCase();

  // Abaikan jika sudah ditangani oleh adapter khusus
  if (
    host.includes('chatgpt.com') ||
    host.includes('youtube.com') ||
    host.includes('github.com')
  ) {
    return;
  }

  const PLATFORM = host.replace(/^www\./, '');
  let currentActivity = 'reading';
  let isTyping = false;
  let typingTimeout = null;

  function updateActivity(newActivity) {
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      newActivity = 'idle';
    }

    if (currentActivity !== newActivity) {
      currentActivity = newActivity;
      window.postMessage({ type: 'GTA_ACTIVITY_UPDATE', activity: currentActivity }, '*');
      try {
        chrome.runtime.sendMessage({
          type: 'ACTIVITY_CHANGED',
          platform: PLATFORM,
          activity: currentActivity,
        });
      } catch (_) {}
    }
  }

  // 1. Deteksi "Mengetik" (Input, textarea, contenteditable, code editor Monaco/CodeMirror)
  function setupTypingDetection() {
    document.addEventListener(
      'input',
      (e) => {
        const target = e.target;
        if (
          target &&
          (target.tagName === 'INPUT' ||
            target.tagName === 'TEXTAREA' ||
            target.getAttribute('contenteditable') === 'true' ||
            target.closest('.monaco-editor, .cm-editor, .ace_editor, [role="textbox"]'))
        ) {
          isTyping = true;
          clearTimeout(typingTimeout);
          evaluateActivity();

          typingTimeout = setTimeout(() => {
            isTyping = false;
            evaluateActivity();
          }, 3500);
        }
      },
      { passive: true, capture: true }
    );
  }

  // 2. Evaluasi aktivitas umum
  function evaluateActivity() {
    if (window.GreatIdleDetector && window.GreatIdleDetector.isIdle()) {
      updateActivity('idle');
      return;
    }

    if (isTyping) {
      updateActivity('typing');
    } else {
      updateActivity('reading');
    }
  }

  // 3. Listener Idle dari idle-detector
  if (window.GreatIdleDetector) {
    window.GreatIdleDetector.onStateChange((isIdle) => {
      if (isIdle) {
        updateActivity('idle');
      } else {
        evaluateActivity();
      }
    });
  }

  // 4. Query berkala setiap 2 detik
  setInterval(evaluateActivity, 2000);

  // 5. Respons saat background service worker bertanya status aktif
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'QUERY_ACTIVITY') {
      evaluateActivity();
      sendResponse({
        activity: currentActivity,
        isIdle: window.GreatIdleDetector ? window.GreatIdleDetector.isIdle() : false,
      });
    }
  });

  // Inisialisasi
  setupTypingDetection();
  evaluateActivity();
  console.log(`[GreatTracker] Universal tracker active for domain: ${PLATFORM}`);
})();
